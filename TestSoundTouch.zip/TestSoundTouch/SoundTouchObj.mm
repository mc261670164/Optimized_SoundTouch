//
//  SoundTouchObj.m
//  TestSoundTouch
//
//  Created by MC Macbook on 2017/9/7.
//  Copyright © 2017年 Ma Chao. All rights reserved.
//

#import "SoundTouchObj.h"
#include "SoundTouch.h"
#include "WaveHeader.h"

using namespace soundtouch;


@implementation SoundTouchObj

- (void)updataAudioSampleRate:(int)sampleRate tempoChangeValue:(int)tempoChange pitchSemiTones:(int)pitch rateChange:(int)rate

{
    soundtouch::SoundTouch mSoundTouch;
    mSoundTouch.setSampleRate(sampleRate); //setSampleRate
    mSoundTouch.setChannels(2);       //设置声音的声道
    mSoundTouch.setTempoChange(tempoChange);    //这个就是传说中的变速不变调
    mSoundTouch.setPitchSemiTones(pitch); //设置声音的pitch (集音高变化semi-tones相比原来的音调) //男: -8 女:8
    mSoundTouch.setRateChange(rate);     //设置声音的速率
    mSoundTouch.setSetting(SETTING_SEQUENCE_MS, 40);
    mSoundTouch.setSetting(SETTING_SEEKWINDOW_MS, 15); //寻找帧长
    mSoundTouch.setSetting(SETTING_OVERLAP_MS, 8);  //重叠帧长
    
    NSMutableData *soundTouchDatas = [[NSMutableData alloc] init];
    for (int i = 0; i < self.dataArr.count; i++) {
        
        NSData *audioData = [self.dataArr objectAtIndex:i];
        
        if (audioData != nil) {
            
            char *pcmData = (char *)audioData.bytes;
            int pcmSize = (int)audioData.length;
            int nSamples = pcmSize / 4;
            mSoundTouch.putSamples((short *)pcmData, nSamples);
            short *samples = new short[pcmSize];
            int numSamples = 0;
            do {
                memset(samples, 0, pcmSize);
                numSamples = mSoundTouch.receiveSamples(samples, pcmSize);
                [soundTouchDatas appendBytes:samples length:numSamples*4];
                
            } while (numSamples > 0);
            delete [] samples;
            
        }
    }
    
    NSMutableData *wavDatas = [[NSMutableData alloc] init];
    [wavDatas appendData:soundTouchDatas];
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *filePath = [path stringByAppendingPathComponent:@"soundtouch.pcm"];
    NSLog(@"%@", filePath);
    BOOL isSave = [wavDatas writeToFile:filePath atomically:YES];
    [soundTouchDatas release];
    [wavDatas release];
    if (isSave)
    {
        NSLog(@"变声结束...\n");
    }
}

@end
