//
//  SoundTouchObj.m
//  SoundTouchDemo
//
//  Created by chuliangliang on 14-5-19.
//  Copyright (c) 2014年 ios. All rights reserved.
//

#ifndef PCM2Wave_WaveHeader_h
#define PCM2Wave_WaveHeader_h

void *createWaveHeader(int fileLength, short channel, int sampleRate, short bitPerSample);

#endif
