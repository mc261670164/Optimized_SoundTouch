//
//  SoundTouchObj.h
//  TestSoundTouch
//
//  Created by MC Macbook on 2017/9/7.
//  Copyright © 2017年 Ma Chao. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SoundTouchObj;
@protocol SoundTouchObjDelegate <NSObject>

- (void)didSaveAndPlay;

@end

@interface SoundTouchObj : NSObject
@property (nonatomic,retain)NSArray *dataArr;
@property (nonatomic,assign)id <SoundTouchObjDelegate> delegate;
- (void)updataAudioSampleRate:(int)sampleRate tempoChangeValue:(int)tempoChange pitchSemiTones:(int)pitch rateChange:(int)rate;
@end
