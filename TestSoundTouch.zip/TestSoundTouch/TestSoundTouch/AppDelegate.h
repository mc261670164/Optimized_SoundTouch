//
//  AppDelegate.h
//  TestSoundTouch
//
//  Created by MC Macbook on 2017/9/7.
//  Copyright © 2017年 Ma Chao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

