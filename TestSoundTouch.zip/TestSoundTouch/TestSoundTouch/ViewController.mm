//
//  ViewController.m
//  TestSoundTouch
//
//  Created by MC Macbook on 2017/9/7.
//  Copyright © 2017年 Ma Chao. All rights reserved.
//

#import "ViewController.h"
#include "SoundTouchObj.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)ChangeVoice:(id)sender
{
    SoundTouchObj *_soundtouch = [[SoundTouchObj alloc] init];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"number" ofType:@"wav"];
    NSData *data = [NSData dataWithContentsOfFile:filePath];
    NSArray *Arr = @[data];
    _soundtouch.dataArr = Arr;
    [_soundtouch updataAudioSampleRate:44100 tempoChangeValue:0 pitchSemiTones:10 rateChange:0];
    _soundtouch.dataArr = nil;
    [_soundtouch dealloc];
}


- (void)didSaveAndPlay
{
    NSLog(@"变声结束...\n");
    
}

@end
