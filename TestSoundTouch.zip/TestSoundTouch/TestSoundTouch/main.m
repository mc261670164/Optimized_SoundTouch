//
//  main.m
//  TestSoundTouch
//
//  Created by MC Macbook on 2017/9/7.
//  Copyright © 2017年 Ma Chao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
